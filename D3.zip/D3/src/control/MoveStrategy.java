package control;
/**
 *THis interface to select next move.
 * @version 3.0
 * 
 */
public interface MoveStrategy {

	public int selectMove(String btnValue[]);
}
